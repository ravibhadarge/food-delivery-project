# Quick Reference: EKS Migration Checklist

## Your Target Configuration
```
✅ EKS Version:    1.34
✅ Node Count:     1
✅ Instance Type:  c7i-flex.large
✅ Management:     Manual (Managed Node Groups)
```

---

## 🚀 Quick Start

### 1. Backup (2 min)
```bash
# Save your current state
cd your-terraform-directory
terraform state pull > terraform-backup.json
git add -A && git commit -m "Pre-migration backup"
```

### 2. Update Files (1 min)
```bash
# Copy the provided files
cp eks_updated.tf eks.tf
cp node-group_updated.tf node-group.tf
```

### 3. Preview Changes (2 min)
```bash
# See what will change
terraform plan
```

### 4. Apply (10-15 min)
```bash
# Execute the migration
# ⚠️ This will recreate your EKS cluster
terraform apply
```

### 5. Verify (5 min)
```bash
# Update your kubeconfig
aws eks update-kubeconfig --region us-east-1 --name food-delivery-cluster

# Verify cluster
kubectl get nodes -o wide
kubectl get pods -A

# Verify version
aws eks describe-cluster --name food-delivery-cluster --query 'cluster.version'
```

---

## 📋 Pre-Migration Checks

- [ ] Current kubeconfig backed up? (`cp ~/.kube/config ~/.kube/config.backup`)
- [ ] Any running workloads? (Decide if you need to migrate them first)
- [ ] AWS credentials working? (`aws sts get-caller-identity`)
- [ ] Terraform version ≥ 1.0? (`terraform version`)
- [ ] Read the full MIGRATION_GUIDE.md? 

---

## ⏱️ Timing

| Step | Duration | Notes |
|------|----------|-------|
| Backup | 2 min | Quick and safe |
| Plan | 2 min | Review changes carefully |
| Apply | 10-15 min | Cluster will be recreated |
| Kubeconfig Update | <1 min | Quick CLI command |
| Addon Installation | 5-10 min | CNI, DNS, storage |
| Verification | 5 min | Ensure everything works |
| **Total** | **25-35 min** | **Allow 1 hour to be safe** |

---

## 🔍 What Gets Destroyed/Created

### 🗑️ Will Be Destroyed
```
- aws_eks_cluster.main (recreated)
- Auto Mode specific resources
```

### ✨ Will Be Created
```
+ aws_eks_cluster.main (new)
+ aws_eks_node_group.main (new)
+ aws_security_group.eks_nodes (new)
+ Updated IAM policies
```

### ✅ Will Remain Unchanged
```
- VPC and subnets
- KMS keys
- Bastion instance
- ECR registry
```

---

## 🛠️ After Migration: Required Addons

You'll need to manually install these (Auto Mode had them pre-installed):

### 1. VPC CNI (if not present)
```bash
# Check if already installed
kubectl get daemonset -n kube-system aws-node

# If not, install
kubectl apply -f https://raw.githubusercontent.com/aws/amazon-vpc-cni-k8s/master/config/v1.13/aws-vpc-cni.yaml
```

### 2. CoreDNS (if not present)
```bash
# Check addon
aws eks describe-addon \
  --cluster-name food-delivery-cluster \
  --addon-name coredns 2>/dev/null || echo "Not installed"

# Install if needed
aws eks create-addon \
  --cluster-name food-delivery-cluster \
  --addon-name coredns
```

### 3. kube-proxy (if not present)
```bash
# Check addon
aws eks describe-addon \
  --cluster-name food-delivery-cluster \
  --addon-name kube-proxy 2>/dev/null || echo "Not installed"

# Install if needed
aws eks create-addon \
  --cluster-name food-delivery-cluster \
  --addon-name kube-proxy
```

### 4. AWS Load Balancer Controller (optional)
```bash
# Only if you need Kubernetes Services with type LoadBalancer
helm repo add eks https://aws.github.io/eks-charts
helm repo update
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=food-delivery-cluster
```

---

## 🔄 Rollback (If Needed)

```bash
# Emergency rollback to Auto Mode
terraform state push terraform-backup.json
terraform apply -auto-approve

# Or revert file changes
git checkout eks.tf node-group.tf
terraform apply -auto-approve
```

---

## ✅ Post-Migration Verification

Run this verification script:

```bash
#!/bin/bash

echo "🔍 EKS Verification Script"
echo "=========================="

# Check version
echo -e "\n📌 Cluster Version:"
aws eks describe-cluster --name food-delivery-cluster \
  --query 'cluster.version' --output text

# Check nodes
echo -e "\n🖥️  Nodes:"
kubectl get nodes -o wide

# Check instance type
echo -e "\n⚙️  Instance Type:"
kubectl get nodes -o custom-columns=\
NAME:.metadata.name,\
INSTANCE_TYPE:.spec.providerID | grep -oP 'c7i-flex\.large'

# Check node count
echo -e "\n📊 Node Count:"
kubectl get nodes --no-headers | wc -l

# Check node group
echo -e "\n📋 Node Group Status:"
aws eks describe-nodegroup \
  --cluster-name food-delivery-cluster \
  --nodegroup-name food-delivery-node-group \
  --query 'nodegroup.[status, scalingConfig]' \
  --output text

# Check addons
echo -e "\n🔧 Addons Installed:"
aws eks list-addons --cluster-name food-delivery-cluster --output table

# Check system pods
echo -e "\n🔄 System Pods:"
kubectl get pods -n kube-system --no-headers | wc -l
echo "System pods running"

echo -e "\n✅ Verification complete!"
```

Save as `verify.sh` and run:
```bash
chmod +x verify.sh
./verify.sh
```

---

## 📞 Troubleshooting

### Issue: Nodes not starting
```bash
# Check node events
kubectl describe node <node-name>

# Check EC2 instance status
aws ec2 describe-instances \
  --filters "Name=tag:aws:eks:cluster-name,Values=food-delivery-cluster" \
  --query 'Reservations[].Instances[].[InstanceId, State.Name, InstanceType]'
```

### Issue: Pods pending
```bash
# Usually means CNI addon not installed
kubectl get pods -A | grep -E 'Pending|0/1'

# Install VPC CNI if missing
kubectl apply -f https://raw.githubusercontent.com/aws/amazon-vpc-cni-k8s/master/config/v1.13/aws-vpc-cni.yaml
```

### Issue: Cannot connect to cluster
```bash
# Update kubeconfig
aws eks update-kubeconfig --region us-east-1 --name food-delivery-cluster

# Test connection
kubectl cluster-info
```

---

## 📚 Documentation Links

- [AWS EKS Documentation](https://docs.aws.amazon.com/eks/)
- [EKS Auto Mode vs Manual](https://docs.aws.amazon.com/eks/latest/userguide/auto-mode.html)
- [Managed Node Groups](https://docs.aws.amazon.com/eks/latest/userguide/managed-node-groups.html)
- [Terraform AWS Provider - EKS](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eks_cluster)

---

## ✨ Summary

**Before Migration:**
- EKS Cluster: Auto Mode (AWS-managed nodes)
- Nodes: Dynamically scaled by AWS
- Configuration: Limited control

**After Migration:**
- EKS Cluster: Manual Mode with Managed Node Groups
- Nodes: 1x c7i-flex.large (you control)
- Configuration: Full Terraform control
- Version: 1.34 (unchanged)

🎉 You're ready to go! Good luck with your migration!

