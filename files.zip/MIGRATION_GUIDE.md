# EKS Configuration Migration Guide
## Auto Mode → Manual Node Management

### Changes Summary

**Target Configuration:**
- ✅ EKS Version: **1.34** (already set in variables.tf)
- ✅ Node Count: **1**
- ✅ Instance Type: **c7i-flex.large**
- ✅ Node Management: **Manual (Managed Node Groups)**

---

## What Changed

### 1. **eks.tf** — EKS Cluster
**Removed:**
- ❌ `compute_config` (Auto Mode compute provisioning)
- ❌ `kubernetes_network_config.elastic_load_balancing` (Auto Mode networking)
- ❌ `storage_config.block_storage` (Auto Mode storage)
- ❌ `bootstrap_self_managed_addons = false`
- ❌ Auto Mode IAM policy attachments:
  - `AmazonEKSComputePolicy`
  - `AmazonEKSNetworkingPolicy`
  - `AmazonEKSBlockStoragePolicy`
  - `AmazonEKSLoadBalancingPolicy`

**Added:**
- ✅ `aws_security_group.eks_nodes` — Worker node security group
- ✅ Standard node IAM role with proper policies

**Why:** Auto Mode requires AWS to manage infrastructure. Manual mode gives you full control over node provisioning, scaling, and configuration.

---

### 2. **node-group.tf** — Node Group Configuration
**Changed from commented to active:**
```hcl
scaling_config {
  desired_size = 1  # One node
  max_size     = 1  # No auto-scaling
  min_size     = 1  # Minimum one node
}
```

**Why:** You now explicitly manage node scaling instead of AWS Auto Mode's automatic provisioning.

---

### 3. **variables.tf**
✅ No changes needed! Your cluster_version is already `1.34`.

---

## Migration Steps

### Step 1: Backup Current State
```bash
# Save current Terraform state
terraform state pull > terraform-backup.json
```

### Step 2: Replace Configuration Files
```bash
# Replace eks.tf with eks_updated.tf
cp eks_updated.tf eks.tf

# Replace node-group.tf with node-group_updated.tf
cp node-group_updated.tf node-group.tf
```

### Step 3: Plan Changes
```bash
terraform plan
```

### Step 4: Review Output
Terraform will show:
- ❌ `aws_eks_cluster.main` — will be destroyed and recreated (requires replacement)
- ✅ `aws_eks_node_group.main` — will be created (new)
- ⚠️ Various IAM policy attachments will be removed/added

### Step 5: Apply Changes
```bash
# This will destroy and recreate the cluster
terraform apply
```

⚠️ **Warning:** This is destructive. Your cluster will be briefly unavailable.

### Step 6: Update kubeconfig
```bash
aws eks update-kubeconfig \
  --region us-east-1 \
  --name food-delivery-cluster
```

---

## What You Need to Do Manually

Since you're switching from Auto Mode (which provisions addon infrastructure), you'll need to manually install/configure:

### 1. **VPC CNI** (Networking)
```bash
kubectl apply -f https://raw.githubusercontent.com/aws/amazon-vpc-cni-k8s/master/config/v1.13/aws-vpc-cni.yaml
```

### 2. **AWS Load Balancer Controller** (if needed)
```bash
helm repo add eks https://aws.github.io/eks-charts
helm repo update
helm install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=food-delivery-cluster
```

### 3. **EBS CSI Driver** (for persistent volumes)
```bash
helm repo add aws-ebs-csi-driver https://kubernetes-sigs.github.io/aws-ebs-csi-driver
helm repo update
helm install aws-ebs-csi-driver aws-ebs-csi-driver/aws-ebs-csi-driver \
  -n kube-system
```

### 4. **CoreDNS Addon** (DNS)
```bash
aws eks create-addon \
  --cluster-name food-delivery-cluster \
  --addon-name coredns
```

---

## Comparison: Auto Mode vs Manual

| Feature | Auto Mode | Manual (Your New Setup) |
|---------|-----------|------------------------|
| Node Provisioning | AWS Managed | Terraform Managed |
| VPC CNI | Auto installed | Manual addon |
| Load Balancer | Auto installed | Manual addon |
| EBS CSI | Auto installed | Manual addon |
| Control | Limited | Full |
| Cost | Often cheaper | Full transparency |
| Setup Time | Faster | More config needed |

---

## Rollback (if needed)

If something goes wrong:
```bash
# Restore from backup
terraform state push terraform-backup.json

# Or destroy and recreate from git
git checkout eks.tf node-group.tf
terraform apply
```

---

## Verification

After migration, verify:
```bash
# Check cluster version
aws eks describe-cluster --name food-delivery-cluster --query 'cluster.version'

# Check node group
aws eks describe-nodegroup \
  --cluster-name food-delivery-cluster \
  --nodegroup-name food-delivery-node-group

# Check nodes running
kubectl get nodes -o wide

# Verify instance type
kubectl get nodes -o custom-columns=NAME:.metadata.name,INSTANCE_TYPE:.spec.providerID
```

---

## Files Provided

1. **eks_updated.tf** — Replace your current eks.tf
2. **node-group_updated.tf** — Replace your current node-group.tf (uncomment)
3. **MIGRATION_GUIDE.md** — This guide

---

## Support

If you encounter issues:
1. Check Terraform logs: `terraform show`
2. Verify AWS permissions
3. Review EKS cluster events: `kubectl describe nodes`
4. Check addon status: `aws eks list-addons --cluster-name food-delivery-cluster`

Good luck! 🚀
