# ═══════════════════════════════════════════════════════════════════
# EKS Managed Node Group
# Single node: c7i-flex.large for manual node management
# ═══════════════════════════════════════════════════════════════════

resource "aws_eks_node_group" "main" {
  cluster_name    = aws_eks_cluster.main.name
  node_group_name = "food-delivery-node-group"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = aws_subnet.private[*].id

  # Single c7i-flex.large instance
  instance_types = ["c7i-flex.large"]

  # Manual scaling configuration
  scaling_config {
    desired_size = 1
    max_size     = 1
    min_size     = 1
  }

  # Update strategy: replace one node at a time
  update_config {
    max_unavailable = 1
  }

  # Node labels
  labels = {
    role = "worker"
  }

  # Ensure proper ordering
  depends_on = [
    aws_iam_role_policy_attachment.eks_node_worker_policy,
    aws_iam_role_policy_attachment.eks_node_cni_policy,
    aws_iam_role_policy_attachment.eks_node_ecr_policy,
  ]

  tags = {
    Name = "food-delivery-node-group"
  }
}
