# Configuration Differences: Auto Mode → Manual Management

## EKS Cluster Configuration Changes

### REMOVED: Auto Mode Policies
```hcl
# ❌ REMOVED - No longer needed for manual mode
resource "aws_iam_role_policy_attachment" "eks_compute_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSComputePolicy"
  role       = aws_iam_role.eks_cluster.name
}

resource "aws_iam_role_policy_attachment" "eks_networking_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSNetworkingPolicy"
  role       = aws_iam_role.eks_cluster.name
}

resource "aws_iam_role_policy_attachment" "eks_block_storage_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSBlockStoragePolicy"
  role       = aws_iam_role.eks_cluster.name
}

resource "aws_iam_role_policy_attachment" "eks_load_balancing_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSLoadBalancingPolicy"
  role       = aws_iam_role.eks_cluster.name
}
```

### REMOVED: Auto Mode Configuration Block
```hcl
# ❌ REMOVED - Auto Mode specific configurations
bootstrap_self_managed_addons = false

compute_config {
  enabled       = true
  node_pools    = ["general-purpose", "system"]
  node_role_arn = aws_iam_role.eks_node.arn
}

kubernetes_network_config {
  elastic_load_balancing {
    enabled = true
  }
}

storage_config {
  block_storage {
    enabled = true
  }
}
```

### ADDED: Manual Node Configuration
```hcl
# ✅ ADDED - Manual control via Terraform
resource "aws_security_group" "eks_nodes" {
  name        = "food-delivery-eks-nodes-sg"
  description = "Security group for EKS worker nodes"
  vpc_id      = aws_vpc.main.id

  # Nodes communicate with each other
  ingress {
    description = "Allow nodes to communicate with each other"
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    self        = true
  }

  # Cluster communicates with nodes
  ingress {
    description     = "Allow cluster to communicate with nodes"
    from_port       = 1025
    to_port         = 65535
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_cluster.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

### CHANGED: Node IAM Role Policies
```hcl
# ❌ OLD (Auto Mode minimal)
resource "aws_iam_role_policy_attachment" "eks_node_worker_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodeMinimalPolicy"
  role       = aws_iam_role.eks_node.name
}

# ✅ NEW (Manual mode standard)
resource "aws_iam_role_policy_attachment" "eks_node_worker_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.eks_node.name
}

# ✅ NEW (Manual mode needs CNI)
resource "aws_iam_role_policy_attachment" "eks_node_cni_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.eks_node.name
}
```

---

## Node Group Configuration Changes

### BEFORE: Commented Out
```hcl
/*
resource "aws_eks_node_group" "main" {
  # ... configuration hidden ...
}
*/
```

### AFTER: Active with Single Node
```hcl
resource "aws_eks_node_group" "main" {
  cluster_name    = aws_eks_cluster.main.name
  node_group_name = "food-delivery-node-group"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = aws_subnet.private[*].id

  instance_types = ["c7i-flex.large"]  # ✅ Your requested instance type

  scaling_config {
    desired_size = 1  # ✅ Single node
    max_size     = 1  # ✅ No auto-scaling
    min_size     = 1  # ✅ Always 1 node
  }

  update_config {
    max_unavailable = 1
  }

  labels = {
    role = "worker"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_node_worker_policy,
    aws_iam_role_policy_attachment.eks_node_cni_policy,
    aws_iam_role_policy_attachment.eks_node_ecr_policy,
  ]

  tags = {
    Name = "food-delivery-node-group"
  }
}
```

---

## Summary of Changes

### Infrastructure Changes
| Component | Auto Mode | Manual Mode |
|-----------|-----------|-------------|
| **Node Provisioning** | AWS Auto Mode | Terraform Managed Node Groups |
| **Node Count** | Dynamic (auto-scaled by AWS) | Fixed to 1 (defined in terraform) |
| **Instance Type** | AWS default selection | c7i-flex.large (your choice) |
| **Security Groups** | Auto-created by AWS | Manually defined |
| **IAM Roles** | Specialized auto mode roles | Standard worker node roles |
| **Addons** | Auto-installed | Manual installation required |

### IAM Policy Changes
```
Removed:
- AmazonEKSComputePolicy
- AmazonEKSNetworkingPolicy
- AmazonEKSBlockStoragePolicy
- AmazonEKSLoadBalancingPolicy

Added:
- AmazonEKSWorkerNodePolicy (upgraded from Minimal)
- AmazonEKS_CNI_Policy (manual VPC CNI)
```

### Version Information
```
✅ EKS Version: 1.34 (no change - already configured)
✅ Node Type: c7i-flex.large (your requirement)
✅ Node Count: 1 (your requirement)
```

---

## Key Benefits of Manual Mode (For Your Use Case)

1. **Full Control**: You explicitly manage node count and instance types
2. **Cost Predictability**: Know exactly what resources are running
3. **No Auto Mode Restrictions**: Can use any Kubernetes features
4. **Familiar Pattern**: Standard EKS managed node groups
5. **Single Node Efficiency**: Perfect for dev/test environments

---

## Post-Migration Checklist

- [ ] Verify EKS cluster is running version 1.34
- [ ] Verify exactly 1 node is running
- [ ] Verify instance type is c7i-flex.large
- [ ] Install VPC CNI addon
- [ ] Install kube-proxy addon (if not already there)
- [ ] Install coredns addon (if not already there)
- [ ] Test pod networking
- [ ] Verify external access to EKS API

